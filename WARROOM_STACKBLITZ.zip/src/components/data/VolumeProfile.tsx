import React from 'react';
export const VolumeProfile = () => <div>Volume</div>;