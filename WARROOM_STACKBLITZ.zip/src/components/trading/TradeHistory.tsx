import React from 'react';
export const TradeHistory = () => <div>History</div>;