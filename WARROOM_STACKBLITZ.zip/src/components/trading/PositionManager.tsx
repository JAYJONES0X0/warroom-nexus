import React from 'react';
export const PositionManager = () => <div>Positions</div>;