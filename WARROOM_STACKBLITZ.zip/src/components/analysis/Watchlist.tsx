import React from 'react';
export const Watchlist = () => <div>Watchlist</div>;