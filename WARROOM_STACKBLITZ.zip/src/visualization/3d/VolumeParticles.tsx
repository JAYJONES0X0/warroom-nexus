import React from 'react';
export const VolumeParticles = () => <group />;