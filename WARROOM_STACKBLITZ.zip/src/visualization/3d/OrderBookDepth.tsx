import React from 'react';
export const OrderBookDepth = () => <group />;