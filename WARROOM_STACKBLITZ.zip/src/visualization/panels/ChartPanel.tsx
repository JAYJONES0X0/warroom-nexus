import React from 'react';
export const ChartPanel = () => <div>Charts</div>;