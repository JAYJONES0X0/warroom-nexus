import React from 'react';
export const NewsStream = () => <div>News</div>;