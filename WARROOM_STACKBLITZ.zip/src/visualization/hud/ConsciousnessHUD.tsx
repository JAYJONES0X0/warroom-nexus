import React from 'react';
export const ConsciousnessHUD = () => <div />;