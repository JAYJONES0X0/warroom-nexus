import React from 'react';
export const ContextMenu = () => <div />;