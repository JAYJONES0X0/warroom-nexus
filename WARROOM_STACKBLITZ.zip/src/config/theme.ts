// Theme configuration
export const theme = { primary: '#00ffff', secondary: '#ff00ff' };