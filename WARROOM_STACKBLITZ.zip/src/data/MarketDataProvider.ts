// Market data provider
export class MarketDataProvider {}