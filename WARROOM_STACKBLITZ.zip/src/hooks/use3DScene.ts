// 3D scene hook
export const use3DScene = () => ({});