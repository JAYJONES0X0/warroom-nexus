// Color utilities
export const hexToRgb = (hex: string) => ({ r: 0, g: 0, b: 0 });