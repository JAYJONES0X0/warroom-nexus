// Validation utilities
export const isValidSymbol = (s: string) => /^[A-Z]+$/.test(s);