import React from 'react';
export const QuickActions = () => <div />;