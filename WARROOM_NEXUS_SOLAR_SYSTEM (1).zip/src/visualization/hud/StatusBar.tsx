import React from 'react';
export const StatusBar = () => <div />;