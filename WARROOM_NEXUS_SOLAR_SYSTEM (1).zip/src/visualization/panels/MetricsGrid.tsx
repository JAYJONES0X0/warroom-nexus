import React from 'react';
export const MetricsGrid = () => <div>Metrics</div>;