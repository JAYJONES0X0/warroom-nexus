import React from 'react';
export const AlertCenter = () => <div>Alerts</div>;