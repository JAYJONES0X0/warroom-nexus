import React, { ReactNode } from 'react';
import { X, Maximize2, Minimize2, Lock, Unlock } from 'lucide-react';
import './HolographicPanel.css';

interface HolographicPanelProps {
  title: string;
  children: ReactNode;
  onClose?: () => void;
  onToggleMaximize?: () => void;
  onToggleLock?: () => void;
  isMaximized?: boolean;
  isLocked?: boolean;
  className?: string;
}

export const HolographicPanel: React.FC<HolographicPanelProps> = ({
  title,
  children,
  onClose,
  onToggleMaximize,
  onToggleLock,
  isMaximized = false,
  isLocked = false,
  className = ''
}) => {
  return (
    <div className={`holographic-panel ${isMaximized ? 'maximized' : ''} ${className}`}>
      <div className="panel-header">
        <div className="panel-title">{title}</div>
        <div className="panel-controls">
          {onToggleLock && (
            <button onClick={onToggleLock} className="panel-control">
              {isLocked ? <Lock size={16} /> : <Unlock size={16} />}
            </button>
          )}
          {onToggleMaximize && (
            <button onClick={onToggleMaximize} className="panel-control">
              {isMaximized ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
            </button>
          )}
          {onClose && (
            <button onClick={onClose} className="panel-control close">
              <X size={16} />
            </button>
          )}
        </div>
      </div>
      <div className="panel-content">
        {children}
      </div>
      <div className="panel-glow"></div>
    </div>
  );
};