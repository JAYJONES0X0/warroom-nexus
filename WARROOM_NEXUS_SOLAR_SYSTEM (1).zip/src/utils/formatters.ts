// Formatting utilities
export const formatNumber = (n: number) => n.toLocaleString();