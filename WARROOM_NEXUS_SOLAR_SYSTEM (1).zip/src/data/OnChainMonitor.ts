// On-chain data monitoring
export class OnChainMonitor {}