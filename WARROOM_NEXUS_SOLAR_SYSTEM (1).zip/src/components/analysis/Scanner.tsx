import React from 'react';
export const Scanner = () => <div>Scanner</div>;