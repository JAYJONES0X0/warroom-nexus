import React from 'react';
export const Correlations = () => <div>Correlations</div>;