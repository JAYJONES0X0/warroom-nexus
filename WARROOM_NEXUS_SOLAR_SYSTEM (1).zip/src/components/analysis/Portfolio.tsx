import React from 'react';
export const Portfolio = () => <div>Portfolio</div>;