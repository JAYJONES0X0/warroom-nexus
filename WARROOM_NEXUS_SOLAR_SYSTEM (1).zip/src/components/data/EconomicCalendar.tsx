import React from 'react';
export const EconomicCalendar = () => <div>Calendar</div>;