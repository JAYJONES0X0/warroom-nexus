import React from 'react';
export const PriceTicker = () => <div>Ticker</div>;