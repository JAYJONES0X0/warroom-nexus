import React from 'react';
export const SentimentGauge = () => <div>Sentiment</div>;