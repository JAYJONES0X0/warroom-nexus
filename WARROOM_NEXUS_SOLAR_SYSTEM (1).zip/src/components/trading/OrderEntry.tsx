import React from 'react';
export const OrderEntry = () => <div>Order Entry</div>;