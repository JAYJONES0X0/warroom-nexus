import React from 'react';
export const RiskCalculator = () => <div>Risk</div>;