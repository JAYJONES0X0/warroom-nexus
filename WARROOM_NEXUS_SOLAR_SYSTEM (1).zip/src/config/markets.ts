// Market configuration
export const defaultWatchlist = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT'];