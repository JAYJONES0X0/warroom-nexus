// Feature flags
export const features = { voice: true, gestures: true };