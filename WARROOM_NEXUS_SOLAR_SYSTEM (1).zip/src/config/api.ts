// API configuration
export const apiConfig = { baseUrl: '' };